$(document).ready(function(){

  $("#showSaveInfo").click(function(){
    $("#saveInfo").toggle();
  });

});