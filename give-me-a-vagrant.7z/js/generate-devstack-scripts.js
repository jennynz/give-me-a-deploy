function GenerateDevStackScripts(vmname) {
	
	return (
	"\n\n#################################################################\n\n" +
	"Give-Me-A-Vagrant for DevStack is on its way!\n\n" +
	"http://woki/display/IntDev/Short-lived+VMs%2C+built+on+demand\n\n" +
	"#################################################################\n\n\n\n"
	);

}