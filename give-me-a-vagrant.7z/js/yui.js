// YUI seed file
<script src="http://yui.yahooapis.com/3.14.0/build/yui/yui-min.js"></script>

<script>
// Create a YUI sandbox on your page.
YUI().use('node', 'event', function (Y) {
    // The Node and Event modules are loaded and ready to use.
    // Your code goes here!
});
</script>